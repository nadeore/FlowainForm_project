<div class="middle-box text-center loginscreen animated fadeInDown">
    <div>
        <div>

            <h1 class="logo-name">IN+</h1>

        </div>
        <h3>Welcome to IN+</h3>
        <p>Perfectly designed and precisely prepared admin theme with over 50 pages with extra new web app views.
            <!--Continually expanded and constantly improved Inspinia Admin Them (IN+)-->
        </p>
        <p>Login in. To see it in action.</p>
        <p style="color: red;"><?php
            echo $error;
            ?></p>
        <form class="m-t" role="form" action="<?php echo site_url('login/in/'); ?>" method="post">
            <div class="form-group">
                <input type="text" class="form-control" name="username" placeholder="Username" >
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password" >
            </div>
            <input type="submit" name="Login" class="btn btn-primary block full-width m-b" value="Login">

<!--            <a href="#"><small>Forgot password?</small></a>
            <p class="text-muted text-center"><small>Do not have an account?</small></p>-->
            <a class="btn btn-sm btn-white btn-block" href="<?php echo site_url('login/register/'); ?>">Create an account</a>
        </form><br>
         <a class="btn-warning btn-sm" href="https://accounts.google.com/signin/v2/identifier?hl=en&passive=true&continue=https%3A%2F%2Fwww.google.com%2Fwebhp%3Fhl%3Den%26sa%3DX%26ved%3D0ahUKEwi-rcefodzkAhVGAHIKHalUDGYQPAgH&flowName=GlifWebSignIn&flowEntry=ServiceLogin">Login with Google</a> &nbsp; <a class="btn-warning btn-sm" href="https://www.facebook.com/">Login with Facebook</a>
        <!--<p class="m-t"> <small>Inspinia we app framework base on Bootstrap 3 © 2014</small> </p>-->
    </div>
</div>