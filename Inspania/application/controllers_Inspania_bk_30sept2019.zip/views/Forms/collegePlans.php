
<div class="row">
    <div class="col-lg-12">
        <div class="ibox ">
            <div class="ibox-title">
                <h5>Colleges Information</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-wrench"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#" class="dropdown-item">Config option 1</a>
                        </li>
                        <li><a href="#" class="dropdown-item">Config option 2</a>
                        </li>
                    </ul>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <?php
                $attributes = array('name' => 'collegePlans', 'id' => 'collegePlans', 'class' => 'form-horizontal');
                echo form_open_multipart(site_url('Home/AddCollegePlans/'), $attributes);
                ?>
                <!-- Select Basic -->
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label" for="careerIntrest">Career Intrest</label>
                    <div class="col-md-5">
                        <select id="careerIntrest" name="careerIntrest" class="form-control">
                        </select>
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label" for="plannedHighestEduLvl">Highest Education level Planned</label>
                    <div class="col-md-5">
                        <select id="plannedHighestEduLvl" name="plannedHighestEduLvl" class="form-control">
                            <option value="Specialized training or certificate program">Specialized training or certificate program</option>
                            <option value="Two-year associate of arts or sciences degree (such as AA, AAS, or AS)">Two-year associate of arts or sciences degree (such as AA, AAS, or AS)</option>
                            <option value="Bachelors degree (such as BA or BS)">Bachelors degree (such as BA or BS)</option>
                            <option value="Master's degree (such as MA, MBA, or MS)">Master's degree (such as MA, MBA, or MS)</option>
                            <option value="Doctoral or related degree (such as PhD, JD, MO, DVM)">Doctoral or related degree (such as PhD, JD, MO, DVM)</option>
                            <option value="Other">Other</option>
                            <option value="Undecided">Undecided</option>
                        </select>
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label" for="collegeHousingPlan">Where are you planning to stay during college?</label>
                    <div class="col-md-5">
                        <select id="collegeHousingPlan" name="collegeHousingPlan" class="form-control">
                            <option value="At Home">At Home</option>
                            <option value="On-Campus Housing">On-Campus Housing</option>
                            <option value="Off-Campus Housing">Off-Campus Housing</option>
                            <option value="I don't know">I don't know</option>
                        </select>
                    </div>
                </div>

                <!-- Multiple Radios -->
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label" for="financialAid">Will you apply for financial aid?</label>
                    <div class="col-md-5">
                        <div class="radio">
                            <label for="financialAid-0">
                                <input type="radio" name="financialAid" id="financialAid-0" value="Yes" checked="checked">
                                Yes
                            </label>
                        </div>
                        <div class="radio">
                            <label for="financialAid-1">
                                <input type="radio" name="financialAid" id="financialAid-1" value="No">
                                No
                            </label>
                        </div>
                    </div>
                </div>
                <?php
                
                       $counter = 1;
                if($questions) {
                    foreach ($questions as $ques ) {
                ?>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="collegeHousingPlan"><b>Questions - <?php echo $counter++; ?></b></label>
                        <div class="col-md-10">                        
                            <div class="form-group row">
                                <label class="col-sm-12 col-form-label" for="collegeHousingPlan"> <input type="checkbox" name="questions"> <b> <?php echo $ques->question; ?> </b> </label>                            

                                <div class="col-md-12" style="padding-top: 10px;">
                                <?php    if($ques->options) {
                                        foreach ($ques->options as $opt ) {
                                                   ?>
                                    <input type="checkbox" name="options" > <?php echo $opt->options; ?> <br>
                                    <?php
                                    } } 
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
                } } 
                ?>
                

                <!-- Button -->
                <div class="form-group row  row">
                    <label class="col-sm-2 col-form-label" for="singlebutton"></label>
                    <div class="col-sm-5">
                        <input type="submit" id="singlebutton" name="savecontinue" class="btn btn-primary" value="Save and Continue"> 
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    function singlebutton() {
        alert("Are you Sure!!!")
        window.location.href = "<?php echo base_url('Home') ?>";
    }
</script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('Home') ?>/Occupations',
            success: function (data) {
                var json = JSON.parse(data);
//                console.log(json);
                var propertytype = '<option value="0">--Select Carrers--</option>';
                for (var i = 0; i < json.Occupations.length; i++)
                {
                    propertytype += '<option value="' + json.Occupations[i].id + '">' + json.Occupations[i].occupation + '</option>';
                }
                $("select#careerIntrest").html(propertytype);
            }
        });
    });
</script>
