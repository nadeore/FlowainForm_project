<div class="row">
    <div class="col-lg-12">
        <div class="ibox ">
            <div class="ibox-title">
                <h5>Upload Documents</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-wrench"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#" class="dropdown-item">Config option 1</a>
                        </li>
                        <li><a href="#" class="dropdown-item">Config option 2</a>
                        </li>
                    </ul>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <?php
                $attributes = array('name' => 'Documents', 'id' => 'Documents', 'class' => 'form-horizontal');
                echo form_open_multipart(site_url('Home/addUploadDoc/'), $attributes);
                ?>
                <!-- File Button -->
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label" for="uploadedTranscript">Upload a PDF of your Document</label>
                    <div class="col-md-5">
                        <input id="uploadedTranscript" name="uploadedTranscript" class="input-file" type="file">
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label" for="schoolname">School Name</label>
                    <div class="col-md-5">
                        <select id="schoolName" name="schoolName" class="form-control" value="<?php echo set_value('cityOfBirth'); ?>">
                        </select>
                    </div>
                    <div class="col-md-4">
                        <?php echo form_error('schoolname',"<p class='text-danger'>","</p>");?>
        
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label" for="typeOfTranscript">Type of Document?</label>
                    <div class="col-md-5">
                        <select id="typeOfTranscript" name="typeOfTranscript" class="form-control">
                            <option selected="selected" disabled>--Select--</option>
                            <option value="8th Grade Transcript" <?php echo set_select('typeOfTranscript','8th Grade Transcript'); ?>>8th Grade Transcript</option>
                            <option value="9th Grade Transcript" <?php echo set_select('typeOfTranscript','9th Grade Transcript'); ?>>9th Grade Transcript</option>
                            <option value="10th Grade Transcript" <?php echo set_select('typeOfTranscript','10th Grade Transcript'); ?>>10th Grade Transcript</option>
                            <option value="11th Grade Transcript" <?php echo set_select('typeOfTranscript','11th Grade Transcript'); ?>>11th Grade Transcript</option>
                            <option value="12th Grade Transcript (Actual)" <?php echo set_select('typeOfTranscript','12th Grade Transcript (Actual)'); ?>>12th Grade Transcript (Actual)</option>
                            <option value="12th Grade Transcript (Predicted)" <?php echo set_select('typeOfTranscript','12th Grade Transcript (Predicted)'); ?>>12th Grade Transcript (Predicted)</option>
                            <option value="Letter of Recommendation" <?php echo set_select('typeOfTranscript','Letter of Recommendation'); ?>>Letter of Recommendation</option>
                            <option value="Statement of Purpose" <?php echo set_select('typeOfTranscript','Statement of Purpose'); ?>>Statement of Purpose</option>
                            <option value="Essay" <?php echo set_select('typeOfTranscript','Essay'); ?>>Essay</option>
                            <option value="College Transcript" <?php echo set_select('typeOfTranscript','College Transcript'); ?>>College Transcript</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <?php echo form_error('typeOfTranscript',"<p class='text-danger'>","</p>");?>
        
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label" for="singlebutton"></label>
                    <div class="col-sm-5">
                        <input type="submit" id="singlebutton" name="savecontinue" class="btn btn-primary" value="Save and Continue"> 
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('Home') ?>/schoolName',
            success: function (data) {
                var json = JSON.parse(data);
//                console.log(json);
                var propertytype = '<option value="0">--Select School--</option>';
                for (var i = 0; i < json.school.length; i++)
                {
                    propertytype += '<option value="' + json.school[i].schoolName + '">' + json.school[i].schoolName + '</option>';
                }
                $("select#schoolName").html(propertytype);
            }
        });
    });
    function singlebutton() {
        alert("Are you Sure!!!")
        window.location.href = "<?php echo base_url('Home') ?>";
    }
</script>