
<div class="row">
    <div class="col-lg-12">
        <div class="ibox ">
            <div class="ibox-title">
                <h5>Contact Information</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-wrench"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#" class="dropdown-item">Config option 1</a>
                        </li>
                        <li><a href="#" class="dropdown-item">Config option 2</a>
                        </li>
                    </ul>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <?php
                $attributes = array('name' => 'contact_form', 'id' => 'contact_form', 'class' => 'form-horizontal');
                echo form_open_multipart(site_url('Home/addContactInfo/'), $attributes);
                ?>
                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="streetAddress1">Street Address 1</label>
                    <div class="col-sm-5">
                        <input id="streetAddress1" name="streetAddress1" type="text" placeholder="" class="form-control input-md" required="">
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="streetAddress3">Street Address 2</label>
                    <div class="col-sm-5">
                        <input id="streetAddress3" name="streetAddress2" type="text" placeholder="" class="form-control input-md">
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="streetAddress2">Street Address 3</label>
                    <div class="col-sm-5">
                        <input id="streetAddress2" name="streetAddress3" type="text" placeholder="" class="form-control input-md">
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="city">City</label>
                    <div class="col-sm-5">
                        <input id="city" name="city" type="text" placeholder="" class="form-control input-md" required="">
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="postalCode">Postal Code</label>
                    <div class="col-sm-5">
                        <input id="postalCode" name="postalCode" type="text" placeholder="" class="form-control input-md" required="">
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="regionOrProvince">Region or Province</label>
                    <div class="col-sm-5">
                        <input id="regionOrProvince" name="regionOrProvince" type="text" placeholder="" class="form-control input-md">
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="countryCode">Phone - Country Code</label>
                    <div class="col-sm-5">
                        <select id="countryCode" name="countryCode" class="form-control">
                        </select>
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="mobileNumber">Mobile number</label>
                    <div class="col-sm-5">
                        <input id="mobileNumber" name="mobileNumber" type="text" placeholder="" class="form-control input-md" required="">
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="emailAddress">Email address</label>
                    <div class="col-sm-5">
                        <input id="emailAddress" name="emailAddress" type="text" placeholder="" class="form-control input-md" required="">
                    </div>
                </div>

                <!-- Button -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="singlebutton"></label>
                    <div class="col-sm-5">
                        <input type="submit" id="singlebutton" name="savecontinue" class="btn btn-primary" value="Save and Continue"> 
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function singlebutton() {
        alert("Are you Sure!!!")
        window.location.href = "<?php echo base_url('Home') ?>";
    }
</script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('Home') ?>/getcountriescode',
            success: function (data) {
//                    console.log(data);
                var json = JSON.parse(data);
//                console.log(json.Countries);
                var propertytype = '<option value="0">--Select Country Code--</option>';
                for (var i = 0; i < json.Countries.length; i++)
                {
                    propertytype += '<option value="' + json.Countries[i].countryCode + '">' + json.Countries[i].countryCode + '&nbsp;' + json.Countries[i].countryName + '</option>';
                }
                $("select#countryCode").html(propertytype);
            }
        });
    });
</script>