
<div class="row">
    <div class="col-lg-12">
        <div class="ibox ">
            <div class="ibox-title">
                <h5>Personal Information</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-wrench"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#" class="dropdown-item">Config option 1</a>
                        </li>
                        <li><a href="#" class="dropdown-item">Config option 2</a>
                        </li>
                    </ul>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <?php
                $attributes = array('name' => 'personel_form', 'id' => 'personel_form', 'class' => 'form-horizontal');
                echo form_open_multipart(site_url('Home/addPersonelInfo/'), $attributes);
                ?>
                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="firstName">First Name</label>
                    <div class="col-sm-5">
                        <input id="firstName" name="firstName" type="text" placeholder="" class="form-control input-md" required="">
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="middleInitial">Middle Initial</label>
                    <div class="col-sm-5">
                        <input id="middleInitial" name="middleInitial" type="text" placeholder="" class="form-control input-md">
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="lastName">Last Name</label>
                    <div class="col-sm-5">
                        <input id="lastName" name="lastName" type="text" placeholder="" class="form-control input-md" required="">

                    </div>
                </div>

                <!-- Multiple Radios (inline) -->
                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="gender">Gender</label>
                    <div class="col-sm-5">
                        <select id="gender" name="gender" class="form-control">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Another/Not Listed">Another / Not Listed</option>
                        </select>
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="dateOfBirth">Date of Birth</label>
                    <div class="col-sm-5">
                        <input id="dateOfBirth" name="dateOfBirth" type="date" placeholder="" class="form-control input-md" required="">

                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="countryOfResidence">Country of Residence</label>
                    <div class="col-sm-5">
                        <select id="countryOfResidence" name="countryOfResidence" class="form-control">
                        </select>
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="countryOfBirth">Country of Birth</label>
                    <div class="col-sm-5">
                        <select id="countryOfBirth" name="countryOfBirth" class="form-control">
                        </select>
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="cityOfBirth">City of birth</label>
                    <div class="col-sm-5">
                        <input id="cityOfBirth" name="cityOfBirth" type="text" placeholder="Enter the city where you were born" class="form-control input-md" required="">

                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="noOfYrsInUS">Number of years you have lived in the USA</label>
                    <div class="col-sm-5">
                        <select id="noOfYrsInUS" name="noOfYrsInUS" class="form-control">
                            <option value="0">0</option>
                            <option value="1 Year"> 1 Year</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="20 Years">20 Years</option>
                        </select>
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="noOfYrsOutOfUS">Number of years you have lived outside the USA</label>
                    <div class="col-sm-5">
                        <select id="noOfYrsOutOfUS" name="noOfYrsOutOfUS" class="form-control">
                            <option value="0">0</option>
                            <option value="1 Year"> 1 Year</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value=">20 Years">&gt;20 Years</option>
                        </select>
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="citizenshipStatus">Citizenship Status for USA</label>
                    <div class="col-sm-5">
                        <select id="citizenshipStatus" name="citizenshipStatus" class="form-control">
                            <option value="U.S. Citizen or U.S. National">U.S. Citizen or U.S. National</option>
                            <option value="U.S. Dual Citizen">U.S. Dual Citizen</option>
                            <option value="U.S. Permanent Resident">U.S. Permanent Resident</option>
                            <option value="U.S. Refugee or Asylee">U.S. Refugee or Asylee</option>
                            <option value="Other (Non-US)">Other (Non-US)</option>
                        </select>
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="parentsMaritalStatus">Parent's Marital Status</label>
                    <div class="col-sm-5">
                        <select id="parentsMaritalStatus" name="parentsMaritalStatus" class="form-control">
                            <option value="Married">Married</option>
                            <option value="Separated">Separated</option>
                            <option value="Divorced">Divorced</option>
                            <option value="Never Married">Never Married</option>
                            <option value="Widowed">Widowed</option>
                            <option value="Civil Union/Domestic Partners">Civil Union/Domestic Partners</option>
                        </select>
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="permenantHomeGuardian">Who do you make your permanent home with?</label>
                    <div class="col-sm-5">
                        <select id="permenantHomeGuardian" name="permenantHomeGuardian" class="form-control">
                            <option value="Parent 1">Parent 1</option>
                            <option value="Parent 2">Parent 2</option>
                            <option value="Both Parents">Both Parents</option>
                            <option value="Legal Guardian">Legal Guardian</option>
                            <option value="Other">Other</option>
                            <option value="Ward of the Court/State">Ward of the Court/State</option>
                        </select>
                    </div>
                </div>

                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="singlebutton"></label>
                    <div class="col-sm-5">
                        <input type="submit" id="singlebutton" name="savecontinue" class="btn btn-primary" value="Save and Continue"> 
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
    <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>-->
    <script>
        function singlebutton() {
            alert("Are you Sure!!!")
            window.location.href = "<?php echo base_url('Home') ?>";
        }
    </script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('Home') ?>/getAllCountries',
                success: function (data) {
                    var json = JSON.parse(data);
    //                console.log(json);
                    var propertytype = '<option value="0">--Select Country--</option>';
                    for (var i = 0; i < json.countries.length; i++)
                    {
                        propertytype += '<option value="' + json.countries[i].id + '">' + json.countries[i].countryName + '</option>';
                    }
                    $("select#countryOfResidence").html(propertytype);

                    var propertytype2 = '<option value="0">--Select Country--</option>';
                    for (var i = 0; i < json.countries.length; i++)
                    {
                        propertytype2 += '<option value="' + json.countries[i].id + '">' + json.countries[i].countryName + '</option>';
                    }
                    $("select#countryOfBirth").html(propertytype2);
                }
            });
        });
    </script>