<!--
    
   <!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>INSPINIA | Dashboard</title>

    <link href="<?php echo site_url($this->config->item('theme_path')); ?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo site_url($this->config->item('theme_path')); ?>font-awesome/css/font-awesome.css" rel="stylesheet">

     Toastr style 
    <link href="<?php echo site_url($this->config->item('theme_path')); ?>css/plugins/toastr/toastr.min.css" rel="stylesheet">

     Gritter 
    <link href="<?php echo site_url($this->config->item('theme_path')); ?>js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="<?php echo site_url($this->config->item('theme_path')); ?>css/animate.css" rel="stylesheet">
    <link href="<?php echo site_url($this->config->item('theme_path')); ?>css/style.css" rel="stylesheet">

</head>

<body>   
<div id="wrapper">
<?php if ($this->session->userdata('isLogin')) { ?>
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
                            <img alt="image" class="rounded-circle" src="img/profile_small.jpg"/>
                            <p style="color: white;    margin-left: 30px;"><i class="fa fa-diamond"></i></p>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="block m-t-xs font-bold">David Williams</span>
                                <span class="text-muted text-xs block">Art Director <b class="caret"></b></span>
                            </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a class="dropdown-item" href="profile.html">Profile</a></li>
                                <li><a class="dropdown-item" href="contacts.html">Contacts</a></li>
                                <li><a class="dropdown-item" href="mailbox.html">Mailbox</a></li>
                                <li class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo site_url('login/'); ?>">Logout</a></li>
                            </ul>
                        </div>
                        <div class="logo-element">
                            IN+
                        </div>
                    </li>
                    <li >
                        <a href="<?php echo site_url('Home/'); ?>"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboards</span> <span class="fa arrow"></span></a>
                    </li>
                    <li class="active">
                        <a href="#"><i class="fa fa-diamond"></i> <span class="nav-label">Forms</span> </span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li class="active"><a href="<?php echo site_url('Home/ContactInfo/'); ?>">Contact Info</a></li>
                            <li><a href="<?php echo site_url('Home/PersonelInfo/'); ?>">Personel Info</a></li>
                            <li><a href="<?php echo site_url('Home/ScoreSAT/'); ?>">Test Score SAT</a></li>
                            <li><a href="<?php echo site_url('Home/Test_Score_ACT/'); ?>">Test Score ACT</a></li>
                            <li><a href="<?php echo site_url('Home/Test_Score_TOEFL_iBT/'); ?>">Test Score TOEFL iBT</a></li>
                            <li><a href="<?php echo site_url('Home/Test_Score_IELTS/'); ?>">Test Score IELTS</a></li>
                            <li><a href="<?php echo site_url('Home/Test_Score_SAT_Subject_Tests/'); ?>">Test Score SAT Subject Tests</a></li>
                            <li><a href="<?php echo site_url('Home/Test_Score_IB_Subject_Test/'); ?>">Test Score IB Subject Test</a></li>                        
                            <li><a href="<?php echo site_url('Home/Test_Score_AP_Subject_Tests/'); ?>">Test Score AP Subject Tests</a></li>
                            <li><a href="<?php echo site_url('Home/Mejor_Selection/'); ?>">Mejor Selection</a></li> 
                            <li><a href="<?php echo site_url('Home/Siblings/'); ?>">Siblings Form</a></li>
                            <li><a href="<?php echo site_url('Home/High_Schools/'); ?>">High Schools Form</a></li>
                            <li><a href="<?php echo site_url('Home/Addcollege/'); ?>">Add College Form</a></li>
                            <li><a href="<?php echo site_url('Home/Parent1/'); ?>">Add Parent-1 Form</a></li>
                            <li><a href="<?php echo site_url('Home/Parent2/'); ?>">Add Parent-2 Form</a></li>
                             <li><a href="<?php echo site_url('Home/CollegePlans/'); ?>">College Plans Form</a></li>
                            <li><a href="<?php echo site_url('Home/Honors/'); ?>">Add honors Form</a></li>
                            <li><a href="<?php echo site_url('Home/Essay/'); ?>">Add essay Form</a></li>
                            <li><a href="<?php echo site_url('Home/UploadDoc/'); ?>">Upload Documents Form</a></li>
                        </ul>
                    </li>
                    
                    <li>
                        <a href="#"><i class="fa fa-bar-chart-o"></i> <span class="nav-label">Graphs</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="graph_flot.html">Flot Charts</a></li>
                            <li><a href="graph_morris.html">Morris.js Charts</a></li>
                            <li><a href="graph_rickshaw.html">Rickshaw Charts</a></li>
                            <li><a href="graph_chartjs.html">Chart.js</a></li>
                            <li><a href="graph_chartist.html">Chartist</a></li>
                            <li><a href="c3.html">c3 charts</a></li>
                            <li><a href="graph_peity.html">Peity Charts</a></li>
                            <li><a href="graph_sparkline.html">Sparkline Charts</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="mailbox.html"><i class="fa fa-envelope"></i> <span class="nav-label">Mailbox </span><span class="label label-warning float-right">16/24</span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="mailbox.html">Inbox</a></li>
                            <li><a href="mail_detail.html">Email view</a></li>
                            <li><a href="mail_compose.html">Compose email</a></li>
                            <li><a href="email_template.html">Email templates</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="metrics.html"><i class="fa fa-pie-chart"></i> <span class="nav-label">Metrics</span>  </a>
                    </li>
                    <li>
                        <a href="widgets.html"><i class="fa fa-flask"></i> <span class="nav-label">Widgets</span></a>
                    </li>               
                </ul>

            </div>
        </nav>
<?php } ?>
    <div id="page-wrapper" class="gray-bg dashbard-1">
        <div class="row border-bottom">
            <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                <div class="navbar-header">
                <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                <form role="search" class="navbar-form-custom" action="search_results.html">
                    <div class="form-group">
                        <input type="text" placeholder="Search for something..." class="form-control" name="top-search" id="top-search">
                    </div>
                </form>
            </div>
                <ul class="nav navbar-top-links navbar-right">
                    <li style="padding: 20px">
                        <span class="m-r-sm text-muted welcome-message">Welcome to INSPINIA+ Admin Theme.</span>
                    </li>
                    <li class="dropdown">
                        <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                            <i class="fa fa-envelope"></i>  <span class="label label-warning">16</span>
                        </a>
                        <ul class="dropdown-menu dropdown-messages dropdown-menu-right">
                            <li>
                                <div class="dropdown-messages-box">
                                    <a class="dropdown-item float-left" href="profile.html">
                                        <img alt="image" class="rounded-circle" src="img/a7.jpg">
                                    </a>
                                    <div class="media-body">
                                        <small class="float-right">46h ago</small>
                                        <strong>Mike Loreipsum</strong> started following <strong>Monica Smith</strong>. <br>
                                        <small class="text-muted">3 days ago at 7:58 pm - 10.06.2014</small>
                                    </div>
                                </div>
                            </li>
                            <li class="dropdown-divider"></li>
                            <li>
                                <div class="dropdown-messages-box">
                                    <a class="dropdown-item float-left" href="profile.html">
                                        <img alt="image" class="rounded-circle" src="img/a4.jpg">
                                    </a>
                                    <div class="media-body ">
                                        <small class="float-right text-navy">5h ago</small>
                                        <strong>Chris Johnatan Overtunk</strong> started following <strong>Monica Smith</strong>. <br>
                                        <small class="text-muted">Yesterday 1:21 pm - 11.06.2014</small>
                                    </div>
                                </div>
                            </li>
                            <li class="dropdown-divider"></li>
                            <li>
                                <div class="dropdown-messages-box">
                                    <a class="dropdown-item float-left" href="profile.html">
                                        <img alt="image" class="rounded-circle" src="img/profile.jpg">
                                    </a>
                                    <div class="media-body ">
                                        <small class="float-right">23h ago</small>
                                        <strong>Monica Smith</strong> love <strong>Kim Smith</strong>. <br>
                                        <small class="text-muted">2 days ago at 2:30 am - 11.06.2014</small>
                                    </div>
                                </div>
                            </li>
                            <li class="dropdown-divider"></li>
                            <li>
                                <div class="text-center link-block">
                                    <a href="mailbox.html" class="dropdown-item">
                                        <i class="fa fa-envelope"></i> <strong>Read All Messages</strong>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                            <i class="fa fa-bell"></i>  <span class="label label-primary">8</span>
                        </a>
                        <ul class="dropdown-menu dropdown-alerts">
                            <li>
                                <a href="mailbox.html" class="dropdown-item">
                                    <div>
                                        <i class="fa fa-envelope fa-fw"></i> You have 16 messages
                                        <span class="float-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="dropdown-divider"></li>
                            <li>
                                <a href="profile.html" class="dropdown-item">
                                    <div>
                                        <i class="fa fa-twitter fa-fw"></i> 3 New Followers
                                        <span class="float-right text-muted small">12 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="dropdown-divider"></li>
                            <li>
                                <a href="grid_options.html" class="dropdown-item">
                                    <div>
                                        <i class="fa fa-upload fa-fw"></i> Server Rebooted
                                        <span class="float-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="dropdown-divider"></li>
                            <li>
                                <div class="text-center link-block">
                                    <a href="notifications.html" class="dropdown-item">
                                        <strong>See All Alerts</strong>
                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </li>


                    <li>
                        <a href="<?php echo site_url('login/'); ?>">
                            <i class="fa fa-sign-out"></i> Log out
                        </a>
                    </li>
                    <li>
                        <a class="right-sidebar-toggle">
                            <i class="fa fa-tasks"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>-->


<!--
*
*  INSPINIA - Responsive Admin Theme
*  version 2.9.2
*
-->

<!DOCTYPE html>
<html>

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>INSPINIA | Dashboard</title>

        <link href="<?php echo site_url($this->config->item('theme_path')); ?>css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo site_url($this->config->item('theme_path')); ?>font-awesome/css/font-awesome.css" rel="stylesheet">

        <!-- Toastr style -->
        <link href="<?php echo site_url($this->config->item('theme_path')); ?>css/plugins/toastr/toastr.min.css" rel="stylesheet">

        <!-- Gritter -->
        <link href="<?php echo site_url($this->config->item('theme_path')); ?>js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

        <link href="<?php echo site_url($this->config->item('theme_path')); ?>css/animate.css" rel="stylesheet">
        <link href="<?php echo site_url($this->config->item('theme_path')); ?>css/style.css" rel="stylesheet">

    </head>

    <body>
        <div id="wrapper">
            <?php // if ($this->session->userdata('isLogin')) { ?>
            <nav class="navbar-default navbar-static-side" role="navigation">
                <div class="sidebar-collapse">
                    <ul class="nav metismenu" id="side-menu">
                        <li class="nav-header">
                            <div class="dropdown profile-element">
                                <img alt="image" class="rounded-circle" src="<?php echo site_url($this->config->item('images_path')); ?>profile_small.jpg"/>
                                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                    <span class="block m-t-xs font-bold">David Williams</span>
                                    <span class="text-muted text-xs block">Art Director <b class="caret"></b></span>
                                </a>
                                <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                    <li><a class="dropdown-item" href="profile.html">Profile</a></li>
                                    <li><a class="dropdown-item" href="contacts.html">Contacts</a></li>
                                    <li><a class="dropdown-item" href="mailbox.html">Mailbox</a></li>
                                    <li class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="<?php echo site_url('login/'); ?>">Logout</a></li>
                                </ul>
                            </div>
                            <div class="logo-element">
                                IN+
                            </div>
                        </li>
                        <li>
                            <a href="index.html"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboards</span> <span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li class="active"><a href="index.html">Dashboard v.1</a></li>
                                <li><a href="dashboard_2.html">Dashboard v.2</a></li>
                                <li><a href="dashboard_3.html">Dashboard v.3</a></li>
                                <li><a href="dashboard_4_1.html">Dashboard v.4</a></li>
                                <li><a href="dashboard_5.html">Dashboard v.5 </a></li>
                            </ul>
                        </li>
                        <li  class="active">
                            <a href="#"><i class="fa fa-diamond"></i> <span class="nav-label">Main 7 Forms</span> </span> <span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li><a href="<?php echo site_url('Home/PersonelInfo/'); ?>">Personal Info</a></li>
                                <li><a href="<?php echo site_url('Home/ContactInfo/'); ?>">Contact Info</a></li>
                                <li><a href="<?php echo site_url('Home/Parent1/'); ?>">Add Parent-1 Form</a></li>
                                <li><a href="<?php echo site_url('Home/Parent2/'); ?>">Add Parent-2 Form</a></li>
                                <li><a href="<?php echo site_url('Home/High_Schools/'); ?>">High Schools Form</a></li>
                                <li><a href="<?php echo site_url('Home/CollegePlans/'); ?>">College Plans Form</a></li>
                                <li><a href="<?php echo site_url('Home/Mejor_Selection/'); ?>">Major Selection</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-bar-chart-o"></i> <span class="nav-label">Another Forms</span><span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level collapse">                               
                                <li><a href="<?php echo site_url('Home/ScoreSAT/'); ?>">Test Score SAT</a></li>
                                <li><a href="<?php echo site_url('Home/Test_Score_ACT/'); ?>">Test Score ACT</a></li>
                                <li><a href="<?php echo site_url('Home/Test_Score_TOEFL_iBT/'); ?>">Test Score TOEFL iBT</a></li>
                                <li><a href="<?php echo site_url('Home/Test_Score_IELTS/'); ?>">Test Score IELTS</a></li>
                                <li><a href="<?php echo site_url('Home/Test_Score_SAT_Subject_Tests/'); ?>">Test Score SAT Subject Tests</a></li>
                                <li><a href="<?php echo site_url('Home/Test_Score_IB_Subject_Test/'); ?>">Test Score IB Subject Test</a></li>                        
                                <li><a href="<?php echo site_url('Home/Test_Score_AP_Subject_Tests/'); ?>">Test Score AP Subject Tests</a></li>                                
                                <li><a href="<?php echo site_url('Home/Siblings/'); ?>">Siblings Form</a></li>                                
                                <li><a href="<?php echo site_url('Home/Addcollege/'); ?>">Add College Form</a></li>
                                <li><a href="<?php echo site_url('Home/Honors/'); ?>">Add honors Form</a></li>
                                <li><a href="<?php echo site_url('Home/Essay/'); ?>">Add essay Form</a></li>
                                <li><a href="<?php echo site_url('Home/UploadDoc/'); ?>">Upload Documents Form</a></li>
                            </ul>
                        </li>
                    </ul>

                </div>
            </nav>
<?php //} ?>
            <div id="page-wrapper" class="gray-bg dashbard-1">
                <div class="row border-bottom">
                    <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                        <div class="navbar-header">
                            <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                            <form role="search" class="navbar-form-custom" action="search_results.html">
                                <div class="form-group">
                                    <input type="text" placeholder="Search for something..." class="form-control" name="top-search" id="top-search">
                                </div>
                            </form>
                        </div>
                        <ul class="nav navbar-top-links navbar-right">
                            <li style="padding: 20px">
                                <span class="m-r-sm text-muted welcome-message">Welcome to INSPINIA+ Admin Theme.</span>
                            </li>
                            <li class="dropdown">
                                <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                                    <i class="fa fa-envelope"></i>  <span class="label label-warning">16</span>
                                </a>
                                <ul class="dropdown-menu dropdown-messages dropdown-menu-right">
                                    <li>
                                        <div class="dropdown-messages-box">
                                            <a class="dropdown-item float-left" href="profile.html">
                                                <img alt="image" class="rounded-circle" src="img/a7.jpg">
                                            </a>
                                            <div class="media-body">
                                                <small class="float-right">46h ago</small>
                                                <strong>Mike Loreipsum</strong> started following <strong>Monica Smith</strong>. <br>
                                                <small class="text-muted">3 days ago at 7:58 pm - 10.06.2014</small>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="dropdown-divider"></li>
                                    <li>
                                        <div class="dropdown-messages-box">
                                            <a class="dropdown-item float-left" href="profile.html">
                                                <img alt="image" class="rounded-circle" src="img/a4.jpg">
                                            </a>
                                            <div class="media-body ">
                                                <small class="float-right text-navy">5h ago</small>
                                                <strong>Chris Johnatan Overtunk</strong> started following <strong>Monica Smith</strong>. <br>
                                                <small class="text-muted">Yesterday 1:21 pm - 11.06.2014</small>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="dropdown-divider"></li>
                                    <li>
                                        <div class="dropdown-messages-box">
                                            <a class="dropdown-item float-left" href="profile.html">
                                                <img alt="image" class="rounded-circle" src="img/profile.jpg">
                                            </a>
                                            <div class="media-body ">
                                                <small class="float-right">23h ago</small>
                                                <strong>Monica Smith</strong> love <strong>Kim Smith</strong>. <br>
                                                <small class="text-muted">2 days ago at 2:30 am - 11.06.2014</small>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="dropdown-divider"></li>
                                    <li>
                                        <div class="text-center link-block">
                                            <a href="mailbox.html" class="dropdown-item">
                                                <i class="fa fa-envelope"></i> <strong>Read All Messages</strong>
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                                    <i class="fa fa-bell"></i>  <span class="label label-primary">8</span>
                                </a>
                                <ul class="dropdown-menu dropdown-alerts">
                                    <li>
                                        <a href="mailbox.html" class="dropdown-item">
                                            <div>
                                                <i class="fa fa-envelope fa-fw"></i> You have 16 messages
                                                <span class="float-right text-muted small">4 minutes ago</span>
                                            </div>
                                        </a>
                                    </li>
                                    <li class="dropdown-divider"></li>
                                    <li>
                                        <a href="profile.html" class="dropdown-item">
                                            <div>
                                                <i class="fa fa-twitter fa-fw"></i> 3 New Followers
                                                <span class="float-right text-muted small">12 minutes ago</span>
                                            </div>
                                        </a>
                                    </li>
                                    <li class="dropdown-divider"></li>
                                    <li>
                                        <a href="grid_options.html" class="dropdown-item">
                                            <div>
                                                <i class="fa fa-upload fa-fw"></i> Server Rebooted
                                                <span class="float-right text-muted small">4 minutes ago</span>
                                            </div>
                                        </a>
                                    </li>
                                    <li class="dropdown-divider"></li>
                                    <li>
                                        <div class="text-center link-block">
                                            <a href="notifications.html" class="dropdown-item">
                                                <strong>See All Alerts</strong>
                                                <i class="fa fa-angle-right"></i>
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </li>


                            <li>
                                <a href="<?php echo site_url('login/'); ?>">
                                    <i class="fa fa-sign-out"></i> Log out
                                </a>
                            </li>
                            <li>
                                <a class="right-sidebar-toggle">
                                    <i class="fa fa-tasks"></i>
                                </a>
                            </li>
                        </ul>

                    </nav>
                </div>
