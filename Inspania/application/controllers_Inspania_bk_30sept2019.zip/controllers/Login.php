<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Login extends CI_Controller {


	public function __construct(){
		parent::__construct();
		//load login model
		$this->load->model('login_model');
	}
    
//        public function index(){
//		$data['page_title'] = 'Home';
//		$data['view'] = 'login_view';    
//		$this->template->load_page1($data);
//	}
        
        public function register(){
		$data['page_title'] = 'Home';
		$data['view'] = 'registration';    
		$this->template->load_page1($data);
	}
        
//        function userRegister() {
//           // echo 'Hii';
//            $data = array(
//                        'username' => $this->input->post('username'),
//                        'password' => $this->input->post('password'),
//                        'emailAddress' => $this->input->post('emailAddress')
//                    );
//            $this->db->insert('users',$data);
//            redirect('Home/', 'location');
//        }
         function userRegister() {
         
                //Setting up validations
                    $this->load->library('form_validation');
                    $this->form_validation->set_rules('username', 'Machine Name', 'required|trim');
                    $this->form_validation->set_rules('password', 'Inventory Code', 'required|trim');
                    $this->form_validation->set_rules('emailAddress', 'Serial Number', 'required|trim');

                    if ($this->form_validation->run() == FALSE){

                        $this->register();
                    }
           
                    $data = array(
                        'username' => $this->input->post('username'),
                        'password' => $this->input->post('password'),
                        'emailAddress' => $this->input->post('emailAddress')
                    );
                    $this->db->insert('users',$data);
                    redirect('Login/', 'location');
                 
        }
                
        
	public function index(){
		$this->in();	
	}
//	
//
	public function in(){
 	
		if($this->input->post('Login')){
                    
			$data['username'] = $this->input->post('username');
			$data['password'] = $this->input->post('password');
			
                        
			$logged_in = $this->login_model->check($data);
//			print_r($logged_in);
//                        exit();
			if ($logged_in){
                        $user_session = array(
                            'isLogin' => '2'
                        );
                        $this->session->set_userdata($user_session);
				redirect('Home', 'location');
//				if($logged_in->verified == 1){
//					$company_session = array(
//							'user_id' => $logged_in->id,
//							'email' => $logged_in->email,
//							'first_name' => $logged_in->first_name,
//							'last_name' => $logged_in->last_name,
//							'user_role' => $logged_in->user_role
//						);
//					//update last login
//					$update['last_login'] = date('Y-m-d H:i:s');
//					$this->general_model->modify('tbl_users', 'id', $logged_in->id, $update);
//				
//					$this->session->set_userdata($company_session);
//					redirect('machines', 'location');
//				}else{
//					$this->session->set_flashdata('error', 'Your account is not verified.');
//					redirect('login', 'location');
//				}
			}else
				$this->_drawForm('Login info is not valid.');	
		}else{
                    $this->_drawForm();                
                }
	}

	private function _drawForm($error = NULL){
		$user_session = array(
                    'isLogin' => FALSE
                );
                $this->session->set_userdata($user_session);		
		$data['error'] = $error;
		$data['page_title'] = 'Login';                
		$data['view'] = 'login_view';
//		print_r($data);
//                        exit();				
		$this->template->load_page($data);
	}
//	
//	public function out(){
//		$company_session = array(
//			'user_id' => FALSE,
//            'email' => FALSE,
//            'first_name' => FALSE,
//            'last_name' => FALSE,
//            'user_role' => FALSE
//		);
//		
//		$this->session->set_userdata($company_session);
//		redirect('', 'location');
//	}
//	
//	public function forgot(){
//		
//		//if user already loggedin
//		if ( $this->session->userdata('user_id') && ($this->session->userdata('user_role') == 3))
//			redirect('home', 'location');
//			
//		if($this->input->post('reset')){
//			//Setting up validations
//			$this->load->library('form_validation');
//			$this->form_validation->set_rules('email','email','required|trim|valid_email|max_length[100]|callback__emailCheck');
//			if ($this->form_validation->run() == FALSE){
//				$data['page_title'] = 'Login';
//				$data['view'] = 'login_view';
//				$this->template->load_page($data);	
//			}else{
//				$email = $this->input->post('email', TRUE);
//				$data = $this->general_model->get_single_row_by_id('tbl_users', 'email', $email, 'array');
//							   
//				//create mail template 
//				$user_email = $this->general->email_template($user_subject, $user_message);
//                                
//                $data['body_hade_msg'] = 'Please click the below link to create new password ';
//                $user_subject = "[SA4I] Forgot password - ".date($this->config->item('date_format'));
//                $head_text = 'Forgot password';        
//
//                $user_message = $this->load->view('maillogin_view', $data, TRUE);
//
//                //create mail template 
//                $user_email = $this->general->email_template($head_text, $user_message); 
//                                
//				// send mail to user
//				$this->general->send_mail($data['email'], $this->general->admin_email(), $this->config->item('site_name'), $user_subject, $user_email);
//				$this->session->set_flashdata('pass_reset', 'Reset password link has been sent to mail.');
//				redirect('login/forgot');
//			}
//		}else{
//			$data['page_title'] = 'Login';
//			$data['view'] = 'login_view';
//			$this->template->load_page($data);
//		}
//			
//	}
//	
//	public function forgotPassword(){
//		
//		//if user already loggedin
//		if ( $this->session->userdata('user_id') && ($this->session->userdata('user_role') == 3))
//			redirect('home', 'location');
//			
//		if($this->input->post('changepass')){
//			//Setting up validations
//			$this->load->library('form_validation');
//			
//			$this->form_validation->set_rules('new_pass','New password','required|trim|min_length[5]|max_length[16]|md5');
//			$this->form_validation->set_rules('c_new_pass','Confirm new password','required|trim|min_length[5]|max_length[16]|matches[new_pass]');
//						
//			if ($this->form_validation->run() == FALSE){ 
//				$data['page_title'] = 'Forgot password';
//				$data['view'] = 'profile/changepass_view';
//				$this->template->load_page($data);
//			}
//			else {	 
//				$data['password'] = $this->input->post('new_pass', TRUE);
//				$this->general_model->modify('tbl_users', 'act_key', $this->uri->segment(3), $data);
//				$this->session->set_flashdata('reset_pass', 'Password reset successfully.');
//				redirect('login/forgotPassword/'.$this->uri->segment(3), 'location');
//			}
//		}else{
//			$data['page_title'] = 'Forgot password';
//			$data['view'] = 'profile/changepass_view';
//			$result = $this->general_model->get_single_row_by_id('tbl_users', 'act_key', $this->uri->segment(3));
//			if(!$result)
//				redirect('home', 'location');
//			
//			$this->template->load_page($data);
//		}
//			
//	}
//
//	function _emailCheck(){
//		
//		$result = $this->general_model->get_single_row_by_id('tbl_users', 'email', $this->input->post('email', TRUE));
//		if ($result)
//			return TRUE;
//		else{
//			$this->form_validation->set_message('_emailCheck', 'This email does not exist in our system.');
//			return FALSE;
//		}
//			
//		
//	}
        
		
}

/* End of file login.php */
/* Location: ./application/controllers/login.php */
