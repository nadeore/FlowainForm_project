<div class="row">
    <div class="col-lg-12">
        <div class="ibox ">
            <div class="ibox-title">
                <h5>Parent 2 Information</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-wrench"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#" class="dropdown-item">Config option 1</a>
                        </li>
                        <li><a href="#" class="dropdown-item">Config option 2</a>
                        </li>
                    </ul>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <?php
                $attributes = array('name' => 'parent2', 'id' => '', 'class' => 'form-horizontal');
                echo form_open_multipart(site_url('Home/addparent2/'), $attributes);
                ?>
                    <!-- Select Basic -->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2type">Parent 2 Type</label>
                        <div class="col-md-5">
                            <select id="parent2type" name="Parent2type" class="form-control">
                                <option selected="selected" disabled>--Select Parent--</option>
                                <option value="Mother" <?php echo set_select('Parent2type','Mother'); ?>>Mother</option>
                                <option value="Father" <?php echo set_select('Parent2type','Father'); ?>>Father</option>
                                <option value="I have limited Information about this Parent" <?php echo set_select('Parent2type','I have limited Information about this Parent'); ?>>I have limited Information about this Parent</option>
                        </select>
                        </div>
                    </div>

                    <!-- Select Basic -->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2Living">Is Parent 2 Living?</label>
                        <div class="col-md-5">
                            <select id="parent1Living" name="parent2Living" class="form-control">
                                <option selected="selected" disabled>--Select Option--</option>
                                <option value="Yes" <?php echo set_select('parent2Living','Yes'); ?>>Yes</option>
                                <option value="No" <?php echo set_select('parent2Living','No'); ?>>No</option>
                        </select>
                        </div>
                    </div>

                    <!-- Select Basic -->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2prefix">Prefix</label>
                        <div class="col-md-5">
                            <select id="parent2prefix" name="parent2prefix" class="form-control">
                                <option value="Dr." <?php echo set_select('parent2prefix','Dr.'); ?>>Dr.</option>
                                <option value="Mr." <?php echo set_select('parent2prefix','Mr.'); ?>>Mr.</option>
                                <option value="Ms." <?php echo set_select('parent2prefix','Ms.'); ?>>Ms.</option>
                                <option value="Mrs." <?php echo set_select('parent2prefix','Mrs.'); ?>>Mrs.</option>
                        </select>
                        </div>
                    </div>

                    <!-- Text input-->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2FirstName">First/Given Name</label>  
                        <div class="col-md-5">
                            <input id="parent2FirstName" name="Parent2FirstName" type="text" placeholder="" class="form-control input-md">

                        </div>
                    </div>

                    <!-- Text input-->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2MiddleInitial">Middle Initial</label>  
                        <div class="col-md-5">
                            <input id="parent2MiddleInitial" name="Parent2MiddleInitial" type="text" placeholder="" class="form-control input-md">

                        </div>
                    </div>

                    <!-- Text input-->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2LastName">Last/Family/Surname</label>  
                        <div class="col-md-5">
                            <input id="parent2LastName" name="Parent2LastName" type="text" placeholder="" class="form-control input-md">

                        </div>
                    </div>

                    <!-- Text input-->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2FormerLastName">Former Last/Family/Surname</label>  
                        <div class="col-md-5">
                            <input id="parent2FormerLastName" name="Parent2FormerLastName" type="text" placeholder="" class="form-control input-md">

                        </div>
                    </div>

                    <!-- Select Basic -->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2Suffix">Suffix</label>
                        <div class="col-md-5">
                            <select id="parent2Suffix" name="parent2Suffix" class="form-control">
                                <option selected="selected" disabled>--Select--</option>
                                <option value="Jr." <?php echo set_select('parent2Suffix','Jr.'); ?>>Jr.</option>
                                <option value="Sr." <?php echo set_select('parent2Suffix','Sr.'); ?>>Sr.</option>
                                <option value="II" <?php echo set_select('parent2Suffix','II'); ?>>II</option>
                                <option value="III" <?php echo set_select('parent2Suffix','III'); ?>>III</option>
                                <option value="IV" <?php echo set_select('parent2Suffix','IV'); ?>>IV</option>
                                <option value="V" <?php echo set_select('parent2Suffix','V'); ?>>V</option>
                                <option value="VI" <?php echo set_select('parent2Suffix','VI'); ?>>VI</option>
                                <option value="VII" <?php echo set_select('parent2Suffix','VII'); ?>>VII</option>
                                <option value="VIII" <?php echo set_select('parent2Suffix','VIII'); ?>>VIII</option>
                                <option value="IX" <?php echo set_select('parent2Suffix','IX'); ?>>IX</option>
                                <option value="X" <?php echo set_select('parent2Suffix','X'); ?>>X</option>
                        </select>
                        </div>
                    </div>

                    <!-- Select Basic -->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2CountryOfBirth">Country of Birth</label>
                        <div class="col-md-5">
                            <select id="parent2CountryOfBirth" name="Parent2CountryOfBirth" class="form-control">
                            </select>
                        </div>
                    </div>

                    <!-- Select Basic -->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2Occupation">Occupation</label>
                        <div class="col-md-5">
                            <select id="parent2Occupation" name="Parent2Occupation" class="form-control">
                            </select>
                        </div>
                    </div>

                    <!-- Select Basic -->
                    <div class="form-group  row">
                        <label class="col-sm-2 col-form-label" for="parent2EducationLevel">Education Level</label>
                        <div class="col-md-5">
                            <select id="parent2EducationLevel" name="Parent2EducationLevel" class="form-control">
                                <option selected="selected" disabled>--Select Score--</option>
                                <option value="None" <?php echo set_select('Parent1EducationLevel','None'); ?>>None</option>
                                <option value="Some grade/primary school" <?php echo set_select('parent2EducationLevel','Some grade/primary school'); ?>>Some grade/primary school</option>
                                <option value="completed grade/primary school" <?php echo set_select('parent2EducationLevel','completed grade/primary school'); ?>>completed grade/primary school</option>
                                <option value="some high/secondary school" <?php echo set_select('parent2EducationLevel','some high/secondary school'); ?>>some high/secondary school</option>
                                <option value="Graduated from high/secondary school (or equivalent)" <?php echo set_select('parent2EducationLevel','Graduated from high/secondary school (or equivalent)'); ?>>Graduated from high/secondary school (or equivalent)</option>
                                <option value="Some trade school or community college" <?php echo set_select('parent2EducationLevel','Some trade school or community college'); ?>>Some trade school or community college</option>
                                <option value="Graduated fro trade school or community college" <?php echo set_select('parent2EducationLevel','Graduated fro trade school or community college'); ?>>Graduated fro trade school or community college</option>
                                <option value="some college/University" <?php echo set_select('parent2EducationLevel','some college/University'); ?>>some college/University</option>
                                <option value="Graduated from college/University" <?php echo set_select('parent2EducationLevel','Graduated from college/University'); ?>>Graduated from college/University</option>
                                <option value="Graduate School" <?php echo set_select('parent2EducationLevel','Graduate School'); ?>>Graduate School</option>
                            </select>
                        </div>
                    </div>

                    
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="singlebutton"></label>
                    <div class="col-sm-5">
                        <input type="submit" id="singlebutton" name="savecontinue" class="btn btn-primary" value="Save and Continue"> 
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
    <script>
        function singlebutton() {
            alert("Are you Sure!!!")
            window.location.href = "<?php echo base_url('Home') ?>";
        }
    </script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('Home') ?>/getAllCountries',
                success: function (data) {
                    var json = JSON.parse(data);
    //                console.log(json);
                    var propertytype = '<option value="0">--Select School Country--</option>';
                    for (var i = 0; i < json.countries.length; i++)
                    {
                        propertytype += '<option value="' + json.countries[i].id + '">' + json.countries[i].countryName + '</option>';
                    }
                    $("select#parent2CountryOfBirth").html(propertytype);
                }
            });


            $.ajax({
                type: 'POST',
                url: '<?php echo base_url('Home') ?>/Occupations',
                success: function (data) {
                    var json = JSON.parse(data);
    //                console.log(json);
                    var propertytype = '<option value="0">--Select Occupation--</option>';
                    for (var i = 0; i < json.Occupations.length; i++)
                    {
                        propertytype += '<option value="' + json.Occupations[i].id + '">' + json.Occupations[i].occupation + '</option>';
                    }
                    $("select#parent2Occupation").html(propertytype);
                }
            });
        });
    </script>
