<div class="row">
    <div class="col-lg-12">
        <div class="ibox ">
            <div class="ibox-title">
                <h5>Parent 1 Information</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-wrench"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#" class="dropdown-item">Config option 1</a>
                        </li>
                        <li><a href="#" class="dropdown-item">Config option 2</a>
                        </li>
                    </ul>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <?php
                $attributes = array('name' => 'parent1', 'id' => '', 'class' => 'form-horizontal');
                echo form_open_multipart(site_url('Home/addparent1/'), $attributes);
                ?>

                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="Parent1type">Parent 1 Type</label>
                    <div class="col-md-5">
                        <select id="Parent1type" name="Parent1type" class="form-control">
                            <option selected="selected" disabled>--Select Parent--</option>
                            <option value="Mother" <?php echo set_select('Parent1type','Mother'); ?>>Mother</option>
                            <option value="Father" <?php echo set_select('Parent1type','Father'); ?>>Father</option>
                            <option value="I have limited Information about this Parent" <?php echo set_select('Parent1type','I have limited Information about this Parent'); ?>>I have limited Information about this Parent</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <?php echo form_error('Parent1type',"<p class='text-danger'>","</p>");?>
        
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="parent1Living">Is Parent 1 Living?</label>
                    <div class="col-md-5">
                        <select id="parent1Living" name="parent1Living" class="form-control">
                            <option selected="selected" disabled>--Select Option--</option>
                            <option value="Yes" <?php echo set_select('parent1Living','Yes'); ?>>Yes</option>
                            <option value="No" <?php echo set_select('parent1Living','No'); ?>>No</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <?php echo form_error('parent1Living',"<p class='text-danger'>","</p>");?>
        
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="Parent1prefix">Prefix</label>
                    <div class="col-md-5">
                        <select id="Parent1prefix" name="Parent1prefix" class="form-control">
                            <option value="Dr." <?php echo set_select('Parent1prefix','Dr.'); ?>>Dr.</option>
                            <option value="Mr." <?php echo set_select('Parent1prefix','Mr.'); ?>>Mr.</option>
                            <option value="Ms." <?php echo set_select('Parent1prefix','Ms.'); ?>>Ms.</option>
                            <option value="Mrs." <?php echo set_select('Parent1prefix','Mrs.'); ?>>Mrs.</option>
                        </select>
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="Parent1FirstName">First/Given Name</label>  
                    <div class="col-md-5">
                        <input id="Parent1FirstName" name="Parent1FirstName" type="text" placeholder="" class="form-control input-md" value="<?php echo set_value('cityOfBirth'); ?>">

                    </div>
                    <div class="col-md-4">
                        <?php echo form_error('Parent1FirstName',"<p class='text-danger'>","</p>");?>
        
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="Parent1MiddleInitial">Middle Initial</label>  
                    <div class="col-md-5">
                        <input id="Parent1MiddleInitial" name="Parent1MiddleInitial" type="text" placeholder="" class="form-control input-md" value="<?php echo set_value('cityOfBirth'); ?>">

                    </div>
                    <div class="col-md-4">
                        <?php echo form_error('Parent1MiddleInitial',"<p class='text-danger'>","</p>");?>
        
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="Parent1LastName">Last/Family/Surname</label>  
                    <div class="col-md-5">
                        <input id="Parent1LastName" name="Parent1LastName" type="text" placeholder="" class="form-control input-md" value="<?php echo set_value('cityOfBirth'); ?>">

                    </div>
                    <div class="col-md-4">
                        <?php echo form_error('Parent1LastName',"<p class='text-danger'>","</p>");?>
        
                    </div>
                </div>

                <!-- Text input-->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="Parent1FormerLastName">Former Last/Family/Surname</label>  
                    <div class="col-md-5">
                        <input id="Parent1FormerLastName" name="Parent1FormerLastName" type="text" placeholder="" class="form-control input-md" value="<?php echo set_value('cityOfBirth'); ?>">

                    </div>
                    <div class="col-md-4">
                        <?php echo form_error('Parent1FormerLastName',"<p class='text-danger'>","</p>");?>
        
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="Parent1Suffix">Suffix</label>
                    <div class="col-md-5">
                        <select id="Parent1Suffix" name="Parent1Suffix" class="form-control">
                            <option selected="selected" disabled>--Select--</option>
                            <option value="Jr." <?php echo set_select('Parent1Suffix','Jr.'); ?>>Jr.</option>
                            <option value="Sr." <?php echo set_select('Parent1Suffix','Sr.'); ?>>Sr.</option>
                            <option value="II" <?php echo set_select('Parent1Suffix','II'); ?>>II</option>
                            <option value="III" <?php echo set_select('Parent1Suffix','III'); ?>>III</option>
                            <option value="IV" <?php echo set_select('Parent1Suffix','IV'); ?>>IV</option>
                            <option value="V" <?php echo set_select('Parent1Suffix','V'); ?>>V</option>
                            <option value="VI" <?php echo set_select('Parent1Suffix','VI'); ?>>VI</option>
                            <option value="VII" <?php echo set_select('Parent1Suffix','VII'); ?>>VII</option>
                            <option value="VIII" <?php echo set_select('Parent1Suffix','VIII'); ?>>VIII</option>
                            <option value="IX" <?php echo set_select('Parent1Suffix','IX'); ?>>IX</option>
                            <option value="X" <?php echo set_select('Parent1Suffix','X'); ?>>X</option>
                        </select>
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="Parent1CountryOfBirth">Country of Birth</label>
                    <div class="col-md-5">
                        <select id="Parent1CountryOfBirth" name="Parent1CountryOfBirth" class="form-control">
                        </select>
                    </div>
                    <div class="col-md-4">
                        <?php echo form_error('Parent1CountryOfBirth',"<p class='text-danger'>","</p>");?>
        
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="Parent1Occupation">Occupation</label>
                    <div class="col-md-5">
                        <select id="Parent1Occupation" name="Parent1Occupation" class="form-control">
                        </select>
                    </div>
                </div>

                <!-- Select Basic -->
                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="Parent1EducationLevel">Education Level</label>
                    <div class="col-md-5">
                        <select id="Parent1EducationLevel" name="Parent1EducationLevel" class="form-control">
                            <option selected="selected" disabled>--Select Score--</option>
                            <option value="None" <?php echo set_select('Parent1EducationLevel','None'); ?>>None</option>
                            <option value="Some grade/primary school" <?php echo set_select('Parent1EducationLevel','Some grade/primary school'); ?>>Some grade/primary school</option>
                            <option value="completed grade/primary school" <?php echo set_select('Parent1EducationLevel','completed grade/primary school'); ?>>completed grade/primary school</option>
                            <option value="some high/secondary school" <?php echo set_select('Parent1EducationLevel','some high/secondary school'); ?>>some high/secondary school</option>
                            <option value="Graduated from high/secondary school (or equivalent)" <?php echo set_select('Parent1EducationLevel','Graduated from high/secondary school (or equivalent)'); ?>>Graduated from high/secondary school (or equivalent)</option>
                            <option value="Some trade school or community college" <?php echo set_select('Parent1EducationLevel','Some trade school or community college'); ?>>Some trade school or community college</option>
                            <option value="Graduated fro trade school or community college" <?php echo set_select('Parent1EducationLevel','Graduated fro trade school or community college'); ?>>Graduated fro trade school or community college</option>
                            <option value="some college/University" <?php echo set_select('Parent1EducationLevel','some college/University'); ?>>some college/University</option>
                            <option value="Graduated from college/University" <?php echo set_select('Parent1EducationLevel','Graduated from college/University'); ?>>Graduated from college/University</option>
                            <option value="Graduate School" <?php echo set_select('Parent1EducationLevel','Graduate School'); ?>>Graduate School</option>
                        </select>
                    </div>
                </div>

                <div class="form-group  row">
                    <label class="col-sm-2 col-form-label" for="singlebutton"></label>
                    <div class="col-sm-5">
                        <input type="submit" id="singlebutton" name="savecontinue" class="btn btn-primary" value="Save and Continue"> 
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    function singlebutton() {
        alert("Are you Sure!!!")
        window.location.href = "<?php echo base_url('Home') ?>";
    }
</script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('Home') ?>/getAllCountries',
            success: function (data) {
                var json = JSON.parse(data);
                //                console.log(json);
                var propertytype = '<option value="0">--Select School Country--</option>';
                for (var i = 0; i < json.countries.length; i++)
                {
                    propertytype += '<option value="' + json.countries[i].id + '">' + json.countries[i].countryName + '</option>';
                }
                $("select#Parent1CountryOfBirth").html(propertytype);
            }
        });


        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('Home') ?>/Occupations',
            success: function (data) {
                var json = JSON.parse(data);
                //                console.log(json);
                var propertytype = '<option value="0">--Select Occupation--</option>';
                for (var i = 0; i < json.Occupations.length; i++)
                {
                    propertytype += '<option value="' + json.Occupations[i].id + '">' + json.Occupations[i].occupation + '</option>';
                }
                $("select#Parent1Occupation").html(propertytype);
            }
        });
    });
</script>
