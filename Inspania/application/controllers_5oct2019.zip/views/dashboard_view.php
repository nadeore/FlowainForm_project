                          <?php //print_r($_SESSION); ?>
<style>
    .mainBtn{
        margin-top: 50px;
    margin-bottom: 50px;
    float: right;
    }
</style>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-12">
        <button class="btn btn-success btn-lg mainBtn" id="applyNow">APPLY NOW</button>
    </div>
    <div class="col-lg-2">
    </div>
</div>
